# Repository Methodology 

![](../images/Proj1_commitdiagram.png)

![](../images/Proj1_process.png)

